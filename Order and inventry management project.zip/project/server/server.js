import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = 3001;
const JWT_SECRET = 'your-secret-key-here';

// Middleware
app.use(cors());
app.use(express.json());

// Database setup
let db;

const initializeDatabase = async () => {
  db = await open({
    filename: './database.sqlite',
    driver: sqlite3.Database
  });

  // Create tables
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('admin', 'order_manager', 'inventory_manager')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      price DECIMAL(10,2) NOT NULL,
      stock_quantity INTEGER NOT NULL DEFAULT 0,
      min_stock_level INTEGER NOT NULL DEFAULT 10,
      category TEXT,
      sku TEXT UNIQUE,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT UNIQUE NOT NULL,
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
      total_amount DECIMAL(10,2) NOT NULL,
      created_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (created_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL,
      price DECIMAL(10,2) NOT NULL,
      FOREIGN KEY (order_id) REFERENCES orders(id),
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      details TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );
  `);

  // Insert default admin user
  const adminExists = await db.get('SELECT id FROM users WHERE role = "admin"');
  if (!adminExists) {
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await db.run(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      ['admin', 'admin@example.com', hashedPassword, 'admin']
    );
  }

  // Insert sample products
  const productsExist = await db.get('SELECT id FROM products LIMIT 1');
  if (!productsExist) {
    const sampleProducts = [
      { name: 'Laptop Pro', description: 'High-performance laptop', price: 1299.99, stock: 25, category: 'Electronics', sku: 'LP-001' },
      { name: 'Wireless Mouse', description: 'Ergonomic wireless mouse', price: 29.99, stock: 150, category: 'Electronics', sku: 'WM-002' },
      { name: 'Office Chair', description: 'Comfortable office chair', price: 249.99, stock: 45, category: 'Furniture', sku: 'OC-003' },
      { name: 'Desk Lamp', description: 'LED desk lamp', price: 79.99, stock: 8, category: 'Lighting', sku: 'DL-004' },
      { name: 'Monitor Stand', description: 'Adjustable monitor stand', price: 89.99, stock: 30, category: 'Electronics', sku: 'MS-005' }
    ];

    for (const product of sampleProducts) {
      await db.run(
        'INSERT INTO products (name, description, price, stock_quantity, category, sku) VALUES (?, ?, ?, ?, ?, ?)',
        [product.name, product.description, product.price, product.stock, product.category, product.sku]
      );
    }
  }
};

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};

// Role-based authorization
const authorizeRole = (roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
};

// Routes
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// User management routes
app.get('/api/users', authenticateToken, authorizeRole(['admin']), async (req, res) => {
  try {
    const users = await db.all('SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC');
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/users', authenticateToken, authorizeRole(['admin']), async (req, res) => {
  try {
    const { username, email, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const result = await db.run(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, role]
    );
    
    res.json({ id: result.lastID, message: 'User created successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Product management routes
app.get('/api/products', authenticateToken, async (req, res) => {
  try {
    const products = await db.all('SELECT * FROM products ORDER BY name');
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/products', authenticateToken, authorizeRole(['admin', 'inventory_manager']), async (req, res) => {
  try {
    const { name, description, price, stock_quantity, min_stock_level, category, sku } = req.body;
    
    const result = await db.run(
      'INSERT INTO products (name, description, price, stock_quantity, min_stock_level, category, sku) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, description, price, stock_quantity, min_stock_level, category, sku]
    );
    
    res.json({ id: result.lastID, message: 'Product created successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/products/:id', authenticateToken, authorizeRole(['admin', 'inventory_manager']), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, price, stock_quantity, min_stock_level, category, sku } = req.body;
    
    await db.run(
      'UPDATE products SET name = ?, description = ?, price = ?, stock_quantity = ?, min_stock_level = ?, category = ?, sku = ? WHERE id = ?',
      [name, description, price, stock_quantity, min_stock_level, category, sku, id]
    );
    
    res.json({ message: 'Product updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Order management routes
app.get('/api/orders', authenticateToken, async (req, res) => {
  try {
    const orders = await db.all(`
      SELECT o.*, u.username as created_by_name
      FROM orders o
      LEFT JOIN users u ON o.created_by = u.id
      ORDER BY o.created_at DESC
    `);
    res.json(orders);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/orders', authenticateToken, authorizeRole(['admin', 'order_manager']), async (req, res) => {
  try {
    const { customer_name, customer_email, items } = req.body;
    const order_number = `ORD-${Date.now()}`;
    
    // Calculate total amount
    let total_amount = 0;
    for (const item of items) {
      const product = await db.get('SELECT price FROM products WHERE id = ?', [item.product_id]);
      total_amount += product.price * item.quantity;
    }
    
    // Create order
    const orderResult = await db.run(
      'INSERT INTO orders (order_number, customer_name, customer_email, total_amount, created_by) VALUES (?, ?, ?, ?, ?)',
      [order_number, customer_name, customer_email, total_amount, req.user.id]
    );
    
    // Add order items
    for (const item of items) {
      const product = await db.get('SELECT price FROM products WHERE id = ?', [item.product_id]);
      await db.run(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
        [orderResult.lastID, item.product_id, item.quantity, product.price]
      );
      
      // Update stock
      await db.run(
        'UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?',
        [item.quantity, item.product_id]
      );
    }
    
    res.json({ id: orderResult.lastID, order_number, message: 'Order created successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/orders/:id/status', authenticateToken, authorizeRole(['admin', 'order_manager']), async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    await db.run('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
    
    res.json({ message: 'Order status updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Dashboard analytics
app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
  try {
    const totalOrders = await db.get('SELECT COUNT(*) as count FROM orders');
    const totalProducts = await db.get('SELECT COUNT(*) as count FROM products');
    const lowStockProducts = await db.get('SELECT COUNT(*) as count FROM products WHERE stock_quantity <= min_stock_level');
    const pendingOrders = await db.get('SELECT COUNT(*) as count FROM orders WHERE status = "pending"');
    
    const recentOrders = await db.all(`
      SELECT o.*, u.username as created_by_name
      FROM orders o
      LEFT JOIN users u ON o.created_by = u.id
      ORDER BY o.created_at DESC
      LIMIT 5
    `);
    
    res.json({
      totalOrders: totalOrders.count,
      totalProducts: totalProducts.count,
      lowStockProducts: lowStockProducts.count,
      pendingOrders: pendingOrders.count,
      recentOrders
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Low stock alerts
app.get('/api/inventory/alerts', authenticateToken, async (req, res) => {
  try {
    const alerts = await db.all('SELECT * FROM products WHERE stock_quantity <= min_stock_level ORDER BY stock_quantity ASC');
    res.json(alerts);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Initialize database and start server
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});